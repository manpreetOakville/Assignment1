//
//  FinalViewController.swift
//  APIDemo
//
// 

import UIKit
import Alamofire
import SwiftyJSON



class FinalViewController: UIViewController {
    
    //MARK:outlets
    
    //title
    
    @IBOutlet weak var titleLabel: UILabel!
    
   
  
    
    @IBOutlet weak var teamALabel: UILabel!
    
    @IBOutlet weak var teamBLabel: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var timeLabel: UILabel!
    
    @IBOutlet weak var stadiumLabel: UILabel!
    
    @IBOutlet weak var cityLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        parseData()
    }
    
    
    func parseData() {
        let URL = "https://final-project-42465.firebaseio.com/.json"
        
        Alamofire.request(URL).responseJSON {
            
            response in
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
            let jsonResponse = JSON(apiData)
            var responseArray = jsonResponse.dictionaryValue
            
            let item = responseArray;
            self.titleLabel.text! = "FINAL MATCH"
            
            
            let stadium = responseArray["Final MATCH"]?[0]["Stadium"];
            let date = responseArray["Final MATCH"]?[0]["Date"];
            let time = responseArray["Final MATCH"]?[0]["Time"];
            let city = responseArray["Final MATCH"]?[0]["city"];
            let teamA = responseArray["Final MATCH"]?[0]["TeamA"];
            let teamB = responseArray["Final MATCH"]?[0]["TeamB"];
            
            // checking the output
            print(stadium!)
            print(date!)
            print(time!)
            print(city!)
            print(teamA!)
            print(teamB!)
            
            //setting in labels
            self.stadiumLabel.text! = "\(stadium!)"
            self.dateLabel.text! = "\(date!)"
            self.timeLabel.text! = "\(time!)"
            self.cityLabel.text! = "\(city!)"
          
            self.teamALabel.text! = "\(teamA!)"
            self.teamBLabel.text! = " \(teamB!)"
            
            
            
            
        }

    }
    
}
