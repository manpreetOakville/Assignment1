//
//  SemiFinalViewController.swift
//  APIDemo
//
//  

import UIKit
import Alamofire
import SwiftyJSON


class SemiFinalViewController: UIViewController {
    //MARK: Outlet
    
    //Title
    @IBOutlet weak var titleLabel: UILabel!
    //First
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var stadiumLabel: UILabel!
    
    @IBOutlet weak var cityLabel: UILabel!
    
    @IBOutlet weak var teamALabel: UILabel!
    
  
    

    //Second
    @IBOutlet weak var date1Label: UILabel!
   
    @IBOutlet weak var time1Label: UILabel!
    @IBOutlet weak var stadium1Label: UILabel!
    @IBOutlet weak var city1Label: UILabel!
    
    
    @IBOutlet weak var teamBLabel: UILabel!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
         parseData()
    }
    

    func parseData() {
        let URL = "https://final-project-42465.firebaseio.com/.json"
        
        Alamofire.request(URL).responseJSON {
            
            response in
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
            let jsonResponse = JSON(apiData)
            var responseArray = jsonResponse.dictionaryValue
            
            let item = responseArray;
            self.titleLabel.text! = "SEMI FINAL"
            
            //FIRST
            let stadium = responseArray["Semi-Final"]?[0]["Stadium"];
            let date = responseArray["Semi-Final"]?[0]["Date"];
            let time = responseArray["Semi-Final"]?[0]["Time"];
            let city = responseArray["Semi-Final"]?[0]["Place"];
            let teamA = responseArray["Semi-Final"]?[0]["TeamA"];
            let teamB = responseArray["Semi-Final"]?[0]["TeamB"];
            
            // checking the output
            print(stadium!)
            print(date!)
            print(time!)
            print(city!)
            print(teamA!)
            print(teamB!)
            
            //setting in labels
            self.stadiumLabel.text! = "\(stadium!)"
            self.dateLabel.text! = "\(date!)"
            self.timeLabel.text! = "\(time!)"
            self.cityLabel.text! = "\(city!)"
           
            self.teamALabel.text! = "\(teamA!)"
            self.teamBLabel.text! = "\(teamB!)"
            
            //SECOND
            let stadium1 = responseArray["Semi-Final"]?[1]["Stadium1"];
            let date1 = responseArray["Semi-Final"]?[1]["Date1"];
            let time1 = responseArray["Semi-Final"]?[1]["Time1"];
            let city1 = responseArray["Semi-Final"]?[1]["city1"];
            let teamA1 = responseArray["Semi-Final"]?[1]["TeamA1"];
            let teamB1 = responseArray["Semi-Final"]?[1]["TeamB1"];
            
            //setting in labels
            self.stadium1Label.text! = "\(stadium1!)"
            self.date1Label.text! = "\(date1!)"
            self.time1Label.text! = "\(time1!)"
            self.city1Label.text! = "\(city1!)"
            self.teamALabel.text! = "\(teamA!)"
            self.teamBLabel.text! = "\(teamB!)"
            
            
            
        }
       
    }

}
