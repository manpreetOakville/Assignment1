//
//  QuarterFinalViewController.swift
//  APIDemo
//
// 

import UIKit
import Alamofire
import SwiftyJSON

class QuarterFinalViewController: UIViewController {
    
    //MARK: outlet
    
    @IBOutlet weak var titleLabel: UILabel!
    
    
    
    @IBOutlet weak var date1Label: UILabel!
    @IBOutlet weak var time1Label: UILabel!
    @IBOutlet weak var stadium1Label: UILabel!
    @IBOutlet weak var city1Label: UILabel!
   
    @IBOutlet weak var teamALabel: UILabel!
    
    
   
   
    @IBOutlet weak var time2: UILabel!
    @IBOutlet weak var date2: UILabel!
    @IBOutlet weak var stadium2Label: UILabel!
    @IBOutlet weak var city2: UILabel!
  
    @IBOutlet weak var teamBLabel: UILabel!
    
    
  
  

    
    
    
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        parseData()

    }
    
    
    
    
    func parseData() {
        let URL = "https://final-project-42465.firebaseio.com/.json"
        
        Alamofire.request(URL).responseJSON {
            response in
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
            let jsonResponse = JSON(apiData)
            
            var responseArray = jsonResponse.dictionaryValue
            
            let item = responseArray;
            //print(item)
            self.titleLabel.text! = "QUARTER FINAL"
            
            
            //FIRST
            let stadium1 = responseArray["QuarterFinal"]?[0]["Stadium1"];
            let date1 = responseArray["QuarterFinal"]?[0]["Date1"];
            let time1 = responseArray["QuarterFinal"]?[0]["Time1"];
            let city1 = responseArray["QuarterFinal"]?[0]["city1"];
            let teamA = responseArray["QuarterFinal"]?[0]["TeamA"];
            let teamB = responseArray["QuarterFinal"]?[0]["TeamB"];
            
            // checking the output
            print(stadium1!)
            print(date1!)
            print(time1!)
            print(city1!)
            print(teamA!)
            print(teamB!)
            
            //setting in labels
            self.stadium1Label.text! = "\(stadium1!)"
            self.date1Label.text! = "\(date1!)"
            self.time1Label.text! = "\(time1!)"
            self.city1Label.text! = "\(city1!)"
            self.teamALabel.text! = "\(teamA!)"
            self.teamBLabel.text! = "\(teamB!)"
            
            
            // SECOND
            let stadium2 = responseArray["QuarterFinal"]?[1]["Stadium2"];
            let date2 = responseArray["QuarterFinal"]?[1]["Date2"];
            let time2 = responseArray["QuarterFinal"]?[1]["Time2"];
            let city2 = responseArray["QuarterFinal"]?[1]["city2"];
            let teamA1 = responseArray["QuarterFinal"]?[1]["TeamA1"];
            let teamB1 = responseArray["QuarterFinal"]?[1]["Team1"];
            
            //setting in labels
            self.stadium2Label.text! = "\(stadium2!)"
            self.date2.text! = "\(date2!)"
            self.time2.text! = "\(time2!)"
            self.city2.text! = "\(city2!)"
           
            self.teamALabel.text! = "\(teamA!)"
            self.teamBLabel.text! = "\(teamB!)"
            
            
        
          
        }
    
    }
    
    
    
    
    
    
   
}
